/* eslint-disable no-restricted-globals */
// Pull-based streaming service worker supporting Range Requests

self.addEventListener('install', (event) => {
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(self.clients.claim());
});

// Map of requestId -> Resolver function
const pendingRequests = new Map();

self.addEventListener('message', (event) => {
    const data = event.data;
    if (!data) return;

    if (data.type === 'DATA_RESPONSE') {
        const resolver = pendingRequests.get(data.requestId);
        if (resolver) {
            resolver(data.chunk); // chunk is ArrayBuffer
            pendingRequests.delete(data.requestId);
        }
    } else if (data.type === 'DATA_ERROR') {
        const resolver = pendingRequests.get(data.requestId);
        if (resolver) {
            resolver(null); // Resolve null to indicate error
            pendingRequests.delete(data.requestId);
        }
    }
});

self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    if (url.pathname.includes('/virtual-stream/')) {
        // Format: /virtual-stream/{fileId}/{fileSize}?mime={encodedMime}
        const parts = url.pathname.split('/');
        const sizeStr = parts.pop();
        const fileId = parts.pop();
        const fileSize = parseInt(sizeStr, 10);
        const mimeType = url.searchParams.get('mime') || 'video/mp4';

        event.respondWith(handleRangeRequest(event.request, fileId, fileSize, mimeType));
    }
});

async function handleRangeRequest(request, fileId, fileSize, mimeType = 'video/mp4') {
    const rangeHeader = request.headers.get('Range');
    let start = 0;
    let end = fileSize - 1;

    if (rangeHeader) {
        const parts = rangeHeader.replace(/bytes=/, "").split("-");
        const partialStart = parts[0];
        const partialEnd = parts[1];

        start = parseInt(partialStart, 10);
        end = partialEnd ? parseInt(partialEnd, 10) : end;
    }

    // Limit chunk size to 512KB to cleanly align with Telegram page size
    if (end - start > 512 * 1024) {
        end = start + 512 * 1024 - 1;
    }

    // Ask client for data
    const chunk = await requestDataFromClient(fileId, start, end);

    if (!chunk || chunk.byteLength === 0) {
        return new Response("Error fetching data", { status: 500 });
    }

    // Exact actual byte range calculation to satisfy RFC 7233
    const actualEnd = start + chunk.byteLength - 1;

    const headers = new Headers();
    headers.set("Content-Type", mimeType);
    headers.set("Content-Length", String(chunk.byteLength));
    headers.set("Content-Range", `bytes ${start}-${actualEnd}/${fileSize}`);
    headers.set("Accept-Ranges", "bytes");

    return new Response(chunk, {
        status: 206,
        headers: headers
    });
}

async function requestDataFromClient(fileId, start, end) {
    const clients = await self.clients.matchAll({ type: 'window' });
    if (!clients || clients.length === 0) return null;

    // We assume the controlling client is the one to ask. 
    // In a sophisticated app we might check which client initiated the stream.
    // For now, ask the first active one.
    const client = clients[0];

    return new Promise((resolve) => {
        const requestId = Math.random().toString(36).substring(7);
        pendingRequests.set(requestId, resolve);

        // Timeout safety
        setTimeout(() => {
            if (pendingRequests.has(requestId)) {
                pendingRequests.delete(requestId);
                resolve(null);
            }
        }, 15000); // 15s timeout

        client.postMessage({
            type: 'REQUEST_DATA',
            requestId: requestId,
            start: start,
            end: end,
            fileId: fileId // Echo back context
        });
    });
}
